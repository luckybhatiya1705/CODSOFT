import tkinter as tk
from tkinter import messagebox

tasks = []

def add_task():
    task = entry.get()
    if task:
        listbox.insert(tk.END, task)
        tasks.append(task)
        entry.delete(0, tk.END)

def delete_task():
    try:
        selected = listbox.curselection()[0]
        listbox.delete(selected)
        tasks.pop(selected)
    except IndexError:
        messagebox.showwarning("Warning", "No task selected")

root = tk.Tk()
root.title("To-Do List")

entry = tk.Entry(root, width=30)
entry.pack(pady=10)

btn_add = tk.Button(root, text="Add Task", command=add_task)
btn_add.pack(pady=5)

listbox = tk.Listbox(root, width=50)
listbox.pack(pady=10)

btn_del = tk.Button(root, text="Delete Task", command=delete_task)
btn_del.pack(pady=5)

root.mainloop()
